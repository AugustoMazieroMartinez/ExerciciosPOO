/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package main;

import java.sql.SQLException;
import view.usuario.LoginUsuario;

/**
 *
 * @author Tatiana
 */
public class TesteAcessoBD {

    public static void main(String[] args) throws SQLException {
        LoginUsuario login = new LoginUsuario();
        login.setVisible(true);
        login.pack();
        login.setLocationRelativeTo(null);
    }
}

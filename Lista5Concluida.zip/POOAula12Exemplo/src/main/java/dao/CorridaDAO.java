package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Corrida;
import model.Motorista;

/**
 *
 * @author Tatiana
 */
public class CorridaDAO {

    private Connection conn;

    public CorridaDAO() {
        conn = ConnectionFactory.getConnection();
    }

    public void inserir(Corrida corrida) {
        try {
            String sql = "insert into corrida(user_id,motorista_id,origem,destino) values (?,?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, corrida.getUser().getId());
            stmt.setInt(2, corrida.getMotorista().getId());
            stmt.setString(3, corrida.getOrigem());
            stmt.setString(4, corrida.getDestino());
            stmt.execute();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(CorridaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void editar(Corrida corrida) {
        try {
            PreparedStatement stmt = conn.prepareStatement("Update corrida set user_id = ?, motorista_id = ?, origem = ?, destino = ? where id = ?");
            stmt.setInt(1, corrida.getUser().getId());
            stmt.setInt(2, corrida.getMotorista().getId());
            stmt.setString(3, corrida.getOrigem());
            stmt.setString(4, corrida.getDestino());
            stmt.setInt(5, corrida.getId());
            System.out.println("ID: " + corrida.getId());
            System.out.println("UserID: " + corrida.getUser().getId());
            System.out.println("MotoristaID: " + corrida.getMotorista().getId());
            System.out.println("Origem: " + corrida.getOrigem());
            System.out.println("Destino: " + corrida.getDestino());
            stmt.execute();
        } catch (SQLException ex) {
            Logger.getLogger(CorridaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void excluir(int id) {
        try {
            String sql = "delete from corrida where id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(CorridaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Corrida selecionarPorId(int id) {
        Corrida corrida = null;
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from corrida where id = ?");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                corrida = new Corrida(rs.getInt("id"), new UsuarioDAO().selecionarPorCodigo(rs.getInt("user_id")), rs.getString("origem"), rs.getString("destino"), new MotoristaDAO().selecionarPorCodigo(rs.getInt("motorista_id")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return corrida;
    }

    public Corrida selecionarPorId() {
        Corrida corrida = null;
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from corrida order by id desc limit 1");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                corrida = new Corrida(rs.getInt("id"), new UsuarioDAO().selecionarPorCodigo(rs.getInt("user_id")), rs.getString("origem"), rs.getString("destino"), new MotoristaDAO().selecionarPorCodigo(rs.getInt("motorista_id")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return corrida;
    }
}

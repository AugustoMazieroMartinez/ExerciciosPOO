package exercício2dalista;

public class EXAluno {
    public static void main(String[] args){
        Aluno aluno = new Aluno();
        aluno.menu();
    }
}

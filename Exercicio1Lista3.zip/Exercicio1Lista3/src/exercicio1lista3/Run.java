package exercicio1lista3;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Run {

    public ArrayList<Curso> ac = new ArrayList();

    public static void main(String[] args) {
        ArrayList<Curso> ac = new ArrayList();
        Object[] lista = {"Criar Curso", "Criar Aluno", "Remover Aluno", "Mostrar Todos os Cursos", "Mostrar Todos os Alunos do Curso", "Sair"};
        Object selectedInput = JOptionPane.showInputDialog(null, "Escolha uma Opção", "Escolha uma Opção", JOptionPane.INFORMATION_MESSAGE, null, lista, lista[0]);
        do {
            switch (selectedInput.toString()) {
                case "Criar Curso" -> {
                    Curso c = new Curso();
                    c.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Digite o Código do Curso: ")));
                    c.setNome(JOptionPane.showInputDialog("Digite o Nome do Curso: "));
                    c.setCargaHoraria(Integer.parseInt(JOptionPane.showInputDialog("Digite a Carga Horaria do Curso: ")));
                    ac.add(c);
                }
                case "Criar Aluno" -> {
                    Aluno a = new Aluno();
                    int curso = Integer.parseInt(JOptionPane.showInputDialog("Digite o Codigo do Curso: "));
                    int index = -1;
                    for (int i = 0; i < ac.size(); i++) {
                        if (ac.get(i).getCodigo() == curso) {
                            index = i;
                            break;
                        }
                    }
                    if (index != -1) {
                        a.setNome(JOptionPane.showInputDialog("Digite o Nome Do Aluno: "));
                        a.setRa(JOptionPane.showInputDialog("Digite o RA do Aluno: "));
                        ac.get(index).inserirAluno(a);
                    }
                }
                case "Remover Aluno" -> {
                    int codigoCurso = Integer.parseInt(JOptionPane.showInputDialog("Digite o Código do Curso: "));
                    int indexCurso = -1;

                    for (int i = 0; i < ac.size(); i++) {
                        if (ac.get(i).getCodigo() == codigoCurso) {
                            indexCurso = i;
                            break;
                        }
                    }

                    if (indexCurso != -1) {
                        Curso cursoEncontrado = ac.get(indexCurso);

                        String raAluno = JOptionPane.showInputDialog("Digite o RA do Aluno a ser Removido: ");
                        int alunoIndex = -1;
                        ArrayList<Aluno> alunosDoCurso = cursoEncontrado.getAl();
                        for (int i = 0; i < alunosDoCurso.size(); i++) {
                            Aluno aluno = alunosDoCurso.get(i);
                            if (aluno.getRa().equalsIgnoreCase(raAluno)) {
                                alunoIndex = i;
                                break;
                            }
                        }
                        if (alunoIndex != -1) {
                            cursoEncontrado.removerAluno(alunoIndex);
                            JOptionPane.showMessageDialog(null, "Aluno Removido!!!");

                        }
                    }
                }

                case "Mostrar Todos os Cursos" -> {
                    String impressao = "Cursos: \n";
                    for (Curso curso : ac) {
                        impressao += curso.imprimir() + "\n";
                    }
                    JOptionPane.showMessageDialog(null, impressao);
                }

                case "Mostrar Todos os Alunos do Curso" -> {
                    int opcao = Integer.parseInt(JOptionPane.showInputDialog("Digite o Código do Curso: "));
                    int index = -1;
                    for (int i = 0; i < ac.size(); i++) {
                        if (ac.get(i).getCodigo() == opcao) {
                            index = i;
                            break;
                        }
                    }
                    if (index != -1) {
                        Curso cursoEncontrado = ac.get(index);
                        JOptionPane.showMessageDialog(null, cursoEncontrado.imprimirCompleto());
                    }
                }

                case "Sair" -> {
                }
            }
            selectedInput = JOptionPane.showInputDialog(null, "Escolha uma Opção", "Escolha uma Opção", JOptionPane.INFORMATION_MESSAGE, null, lista, lista[0]);
        } while (!selectedInput.equals("Sair"));
    }
}

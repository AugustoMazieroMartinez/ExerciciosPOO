package exercicio1lista3;

import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Curso {
    private int codigo, cargaHoraria;
    private String nome;
    private ArrayList<Aluno> al;
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Aluno> getAl() {
        return al;
    }

    public void setAl(ArrayList<Aluno> a) {
        this.al = a;
    }    
    public Curso(){
        this.al = new ArrayList();
        
    }
    public Curso(int codigo, String nome, int cargaHoraria){
        this.codigo = codigo;
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.al = new ArrayList();
    }
    public void inserirAluno(Aluno aluno){
        al.add(aluno);
    }
    public void removerAluno(int index){
        al.remove(index);
    }
    public String imprimir(){
        return "\nCodigo: " + this.codigo + "\nNome: " + this.nome + "\nCarga Horaria: " + this.cargaHoraria + "\n";
    }
    public String imprimirCompleto(){
        String impressao = imprimir() + "\n";
        int i = -1;
        for (Aluno aluno : al) {
            i++;
            al.get(i);
            impressao += aluno.imprimir() + "\n";
        }
        return impressao;
    }
}